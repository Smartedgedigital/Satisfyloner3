
export default function App() {
  return (
    <div style={{padding: '40px', fontFamily: 'Arial'}}>
      <h1>Smartedge Digital</h1>
      <p>Your full React website is ready. Replace this with your full site content.</p>
    </div>
  )
}
